#!/bin/bash

# Variables
SCRIPT_NAME="start-searxng.sh"
SERVICE_NAME="start-searxng.service"
SERVICE_PATH="/etc/systemd/system/${SERVICE_NAME}"
SCRIPT_PATH="/etc/init.d/${SCRIPT_NAME}"
PROJECT_DIR="/home/toni/xng/searxng-docker-new"

# Función para mostrar mensajes de error y salir
error_exit() {
    echo "Error: $1" >&2
    exit 1
}

# Verificar si se ejecuta como root
if [ "$(id -u)" -ne 0 ]; then
    error_exit "Este script debe ejecutarse con privilegios de root (usa sudo)."
fi

# Verificar si el directorio del proyecto existe
if [ ! -d "$PROJECT_DIR" ]; then
    error_exit "El directorio del proyecto no existe: $PROJECT_DIR"
fi

# Crear el script que ejecutará el comando
cat <<EOF > "$SCRIPT_PATH"
#!/bin/bash
# Script para iniciar searxng con Docker Compose al arrancar el sistema

# Cambiar al directorio correcto
cd $PROJECT_DIR || exit

# Ejecutar el comando docker-compose
docker compose up -d
EOF

# Dar permisos de ejecución al script
chmod +x "$SCRIPT_PATH"

# Crear el archivo de servicio systemd
cat <<EOF > "$SERVICE_PATH"
[Unit]
Description=Start searxng with Docker Compose on boot
After=network.target docker.service
Requires=docker.service

[Service]
Type=oneshot
User=toni
ExecStart=$SCRIPT_PATH
RemainAfterExit=true

[Install]
WantedBy=multi-user.target
EOF

# Recargar systemd y habilitar el servicio
systemctl daemon-reload
systemctl enable "$SERVICE_NAME" || error_exit "No se pudo habilitar el servicio."
systemctl start "$SERVICE_NAME" || error_exit "No se pudo iniciar el servicio."

# Mostrar mensaje de éxito
echo "Configuración completada. El servicio '$SERVICE_NAME' ahora se iniciará automáticamente al arrancar el sistema."
echo "Reinicia tu sistema para verificar que funcione correctamente."
