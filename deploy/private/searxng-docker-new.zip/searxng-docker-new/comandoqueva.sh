docker run -p 8888:8080 -it searxng/searxng
