#!/bin/bash

# Variables
SEARXNG_DIR="./searxng"
CONTAINER_NAME="searxng"
IMAGE_NAME="docker.io/searxng/searxng:latest"

# Función para mostrar mensajes de error y salir
error_exit() {
    echo "Error: $1" >&2
    exit 1
}

# Verificar si el directorio ./searxng existe, si no, crearlo
if [ ! -d "$SEARXNG_DIR" ]; then
    echo "Directorio $SEARXNG_DIR no encontrado. Creando..."
    mkdir -p "$SEARXNG_DIR" || error_exit "No se pudo crear el directorio $SEARXNG_DIR."
fi

# Ajustar permisos del directorio ./searxng
echo "Ajustando permisos del directorio $SEARXNG_DIR..."
chmod 755 "$SEARXNG_DIR" || error_exit "No se pudieron ajustar los permisos de $SEARXNG_DIR."
chown -R "$(id -u):$(id -g)" "$SEARXNG_DIR" || error_exit "No se pudieron cambiar los propietarios de $SEARXNG_DIR."

# Verificar si uwsgi.ini existe, si no, copiarlo desde la imagen del contenedor
UWSGI_INI="$SEARXNG_DIR/uwsgi.ini"
if [ ! -f "$UWSGI_INI" ]; then
    echo "El archivo uwsgi.ini no fue encontrado. Copiando desde la imagen del contenedor..."
    docker run --rm "$IMAGE_NAME" cat /etc/searxng/uwsgi.ini.sample > "$UWSGI_INI" || error_exit "No se pudo copiar uwsgi.ini."
    chmod 644 "$UWSGI_INI" || error_exit "No se pudieron ajustar los permisos de $UWSGI_INI."
else
    echo "El archivo uwsgi.ini ya existe. No es necesario copiarlo."
fi

# Detener y eliminar el contenedor existente (si está en ejecución)
if docker ps -a --filter "name=$CONTAINER_NAME" | grep -q "$CONTAINER_NAME"; then
    echo "Deteniendo y eliminando el contenedor $CONTAINER_NAME..."
    docker stop "$CONTAINER_NAME" >/dev/null 2>&1
    docker rm "$CONTAINER_NAME" >/dev/null 2>&1
fi

# Eliminar volúmenes y redes asociadas
echo "Limpieza de volúmenes y redes asociadas..."
docker compose down --volumes >/dev/null 2>&1

# Reiniciar los servicios
echo "Reiniciando los servicios de Docker Compose..."
docker compose up -d || error_exit "No se pudieron reiniciar los servicios."

# Verificar el estado del contenedor
echo "Verificando el estado del contenedor $CONTAINER_NAME..."
STATUS=$(docker inspect -f "{{.State.Status}}" "$CONTAINER_NAME" 2>/dev/null)

if [ "$STATUS" == "running" ]; then
    echo "El contenedor $CONTAINER_NAME está en ejecución correctamente."
else
    error_exit "El contenedor $CONTAINER_NAME no está en ejecución. Revisa los registros con 'docker logs $CONTAINER_NAME'."
fi

echo "Proceso completado con éxito."
